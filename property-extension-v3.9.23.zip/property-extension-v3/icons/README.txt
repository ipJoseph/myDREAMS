Icon files needed: 16x16, 48x48, 128x128 PNG images
